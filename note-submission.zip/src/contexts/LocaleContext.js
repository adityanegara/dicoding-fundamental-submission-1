import { createContext } from "react";

const LocaleContext = createContext();

export default LocaleContext;